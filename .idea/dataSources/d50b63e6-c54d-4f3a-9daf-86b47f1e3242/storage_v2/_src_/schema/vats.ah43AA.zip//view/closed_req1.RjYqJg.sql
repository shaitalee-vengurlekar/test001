create view closed_req1 as
(
select `rr`.`id` AS `id`
from (((`vats`.`requirement` `rr` left join `vats`.`clients` `cc` on ((`rr`.`client_id` = `cc`.`id`))) left join `vats`.`resume_requirement_map` `rrm` on ((`rrm`.`requirement_id` = `rr`.`id`)))
         left join `vats`.`resumes` `res` on ((`res`.`id` = `rrm`.`resume_id`)))
where ((`rrm`.`id` <> '') and (`rr`.`is_dhm` = 1) and (`rrm`.`status` in (5, 19, 21, 22, 23, 25)))
order by `cc`.`name`, `rr`.`job_title`, `rr`.`created_at` desc);

