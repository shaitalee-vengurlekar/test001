/**
 * @license Highcharts Gantt JS v7.2.1 (2019-10-31)
 * @module highcharts/modules/static-scale
 * @requires highcharts
 *
 * StaticScale
 *
 * (c) 2016-2019 Torstein Honsi, Lars A. V. Cabrera
 *
 * License: www.highcharts.com/license
 */
'use strict';
import '../../modules/static-scale.src.js';
